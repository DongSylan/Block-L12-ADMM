function x = Block_L1L2(A, b, Block_Label, pm)
%min_x .5||Ax-b||^2 + lambda(|x|_21-|x|_2)

%Input: dictionary A, data b, parameters set pm
%       pm.lambda: regularization paramter
%       pm.delta: penalty parameter for ADMM, default value: 10*lambda
%       pm.maxoit: max outer iterations, default value: 10
%       pm.maxit: max inner iterations: default value: 5000
%       pm.tol: outer tolerace, default value: 1e-3
%       pm.abstol: abs tolerance for ADMM: default value: 1e-7
%       pm.reltol: rel tolerance for ADMM: default value: 1e-5
%Output: computed coefficients x
%       output.relerr: relative error of x_n and x_{n-1}
%       output.obj: objective function of x_n

%% DCA for outer interation
[M,N] = size(A);

nGroups = max(Block_Label);
ABC = zeros(nGroups, N);
for i = 1:nGroups
    ABC(i, Block_Label==i) = 1;
end
d = round(N/nGroups);


%% parameters
lambda = 1e-5;
delta = 1e-4;
Outer_MaxIter = 30; 
Inner_MaxIter = 1000; 
x0 = zeros(N, 1);
abstol = 1e-7;
reltol = 1e-5;

if isfield(pm,'lambda'); lambda = pm.lambda; end
if isfield(pm,'delta'); delta = pm.delta; end
if isfield(pm,'Outer_MaxIter'); Outer_MaxIter = pm.Outer_MaxIter; end
if isfield(pm,'Inner_MaxIter');  Inner_MaxIter = pm.Inner_MaxIter; end
if isfield(pm,'x0'); x0 = pm.x0; end
if isfield(pm,'tol'); tol = pm.tol; end
if isfield(pm,'abstol'); abstol = pm.abstol; end
if isfield(pm,'reltol'); reltol = pm.reltol; end


%% pre-computing/initialize
AAt = A*A';
L = chol( speye(M) + 1/delta*AAt, 'lower' );  % L*L' = speye(M) + 1/delta*AAt
L = sparse(L);
U = sparse(L');

x = x0;

Atb = A'*b;
y = zeros(N,1); z = y;

for oit = 1:Outer_MaxIter
    
    v = -lambda*x/(norm(x,2)+1e-16); 
    xold = x;
    
    %ADMM method for solving the sub-problem
    for it = 1:Inner_MaxIter
            %update x
            rhs = Atb -v + delta*(y-z);
            x = rhs/delta - (A'*(U\(L\(A*rhs))))/delta^2;

          
            %update y
            yold = y;
            y =shrink(x+z, lambda/delta, ABC, d);
  
            %update u
            z = z + x-y;
    
            % stopping condition for ADMM 
            r = norm(x-y);
            s = norm(delta*(y-yold));
            
            eps_pri = sqrt(N)*abstol + reltol*max(norm(x),norm(y));
            eps_dual = sqrt(N)*abstol + reltol*norm(z);
            
            if (r < eps_pri && s < eps_dual)
                break;
            end            
            
    end
        
    % Stopping condition for Block-DCA
      stoperr = norm(x-xold, 2)/norm(x, 2);
    if stoperr < tol
        break;
    end
end

end

%% Shrinkage
function z = shrink(x, r, ABC, d)
  t_value = kron((ABC*(x.^2)).^0.5, ones(d, 1));
  z  = max(0, sign(t_value-r)).*(1-r./(t_value+1e-16)).*x;
end



