%% Initializing the enviroment
   close all
   clear all
   clc
   rng('default')
   
   
%% Public parameters
   M = 128;                  % Sample times
   N = 2048;                 % The length of signal
   d = 4;                    % Block size
   m = N/d;                  % number of blocks
   F = 10;    
   RL = 2*F;
   s = 8;                    %  The block-sparsity of signals
 % Pa for block structure              
   Opt_Block = 'even';         % Pa for block structure
 % Pa for block-saprse signals
   Opt_x.Spike = 'Yes';
   Opt_x.Dis = 'randn';
   Opt_x.RL = RL;
 % Pa for measurement matrix
   Opt_Phi.Dis = 'OsP_DCT';
   Opt_Phi.F = F;
   
   
%% Parameters for Block-l1-2 algorithms
   pmB_L1L2.lambda = 1e-5;
   pmB_L1L2.delta = 1e-4;
   pmB_L1L2.Outer_MaxIter = 30; 
   pmB_L1L2.Inner_MaxIter = 1000; 
   pmB_L1L2.x0 = zeros(N, 1);
   pmB_L1L2.tol = 1e-3; 
   pmB_L1L2.abstol = 1e-7;
   pmB_L1L2.reltol = 1e-5;
   
   
%% Main
 % Generate the block structure, block-saprse signal and the measurement matrix,
   P = Phi_x_block(M/d, m, N, s, Opt_Block, Opt_x, Opt_Phi);
   [~, x_Original, Block_Label] = Phi_x_block(M, N, m, s, Opt_Block, Opt_x, Opt_Phi);
   Phi = kron(P, hadamard(d)/sqrt(d));
 % compute (Block)coherence
   fprintf(['Coherence of P is ' num2str(coherence(P)) '\n']);
   b = Phi*x_Original;
 % Recovered via Block-L12
   x_Block_L1L2 = Block_L1L2(Phi, b, Block_Label, pmB_L1L2);   
   
   
%% Figure
    figure
    stem(x_Original, 'r*');
    hold on
    stem(x_Block_L1L2, 'bo');
    legend('Original signal', 'Signal recovered by Block-L12')
    grid on
   
   
   
   
 