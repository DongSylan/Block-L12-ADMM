%% Initializing the enviroment
   close all
   clear all
   clc
   rng('default')
   
   
%% Public parameters
   m = 10;
   d = 25;
 % Block-Label
   Matrix_Block_Label = repmat(1:m, d, 1);
   Block_Label = Matrix_Block_Label(:);
   

%% A and x
    load FOETAL_ECG.mat
    load Phi
    x_Original = FOETAL_ECG(1:250, 3);
    A = Phi;
    [M, N] = size(A);
    b = A*x_Original;
    
    
%% Parameters for Block-l1-2
    pmB_L1L2.delta = 1e-4;
    pmB_L1L2.Outer_MaxIter = 30; 
    pmB_L1L2.Inner_MaxIter = 1000; 
    pmB_L1L2.x0 = zeros(N, 1);
    pmB_L1L2.tol = 1e-3; 
    pmB_L1L2.abstol = 1e-7;
    pmB_L1L2.reltol = 1e-5;
    pmB_L1L2.lambda = 1e1;
   
   
%% lambda_Set for Block_L1L2
    log10_lambda_Set = -8:4;
    Bestlog10lambda_Block_L1L2 = 1;
    x_Best_Block_L1L2 = zeros(N, 10);
    Error_Best_Block_L1L2 = 1e7;
    
   
%% Main   
    x_Block_L1L2 = Block_L1L2(A, b, Block_Label, pmB_L1L2);
    
    
%% Figure
    figure
    stem(x_Original, 'r*');
    hold on
    stem(x_Block_L1L2, 'bo');
    legend('A segment from FECG signals', 'Signal recovered by Block-L12')
    grid on


