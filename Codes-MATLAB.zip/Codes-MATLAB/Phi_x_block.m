function [Phi, x, Block_Label] = Phi_x_block(m, n, NumBlock, s, Opt_Block, Opt_x, Opt_Phi)

% Generate the proper measurement matrix Phi, block-sparse signal x and the block structure label Block_Label                                                                                        
%           m: sample time
%           n: length of signal x
%    NumBlock: number of blocks
%           s: block sparsity
%   Opt_Block: pm for block structure('even','uneven')

%       Opt_x: It includes following terms
%   Opt_x.Dis: pm for the distribute of the block-sparse signal('randn','rand','01')
% Opt_x.Spike: pm for the type of block-sparse signal('Yes', 'No')
%    Opt_x.RL: pm for the Rayleigh length(RL) of block-sparse signal (integer)

%     Opt_Phi: It includes following terms
% Opt_Phi.Dis: pm for the distribute of the measurement matrix('randn','rand','hada-mard',)
%   Opt_Phi.F: The refinement factor of randomly oversampled partial DCT

% Block_Label
switch Opt_Block
    case 'uneven'
         Block_Label = [];
         while (length(unique(Block_Label)) ~= NumBlock)
               Block_Label  = sort(ceil(rand(n,1) * NumBlock)); 
         end
    case 'even'
        NumElement = round(n/NumBlock);
        label_matrix = zeros(NumElement,NumBlock);
        for i_1=1:NumElement
            label_matrix(i_1,:) = 1:NumBlock;
        end
        Block_Label = label_matrix(:);
    otherwise
        disp('Wrong parameters are provided. Please check your input related to ''Block_Label'' carefully.')     
end

% x
  if ~isfield(Opt_x,'Spike')
      Opt_x.Spike = 'No';
  end 
  x  = zeros(n, 1);
  switch Opt_x.Dis
      case  'randn'
          if strcmp(Opt_x.Spike, 'Yes')
              supp = randsample_separated(NumBlock, s, Opt_x.RL);
              Index = ismember(Block_Label,supp);
              x(Index) = randn(sum(Index), 1);
          else
              Index_0 = randperm(NumBlock);
              Index_1 = Index_0(1:s);
              Index_2 = ismember(Block_Label,Index_1);
              x(Index_2) = randn(sum(Index_2), 1);
          end
      case  'rand'
          if strcmp(Opt_x.Spike, 'Yes')
              supp = randsample_separated(NumBlock, s, Opt_x.RL);
              Index = ismember(Block_Label,supp);
              x(Index) = rand(sum(Index), 1);
          else
              Index_0 = randperm(NumBlock);
              Index_1 = Index_0(1:s);
              Index_2 = ismember(Block_Label,Index_1);
              x(Index_2) = rand(sum(Index_2), 1);
          end
      case  '01'
          if strcmp(Opt_x.Spike, 'Yes')
              supp = randsample_separated(NumBlock, s, Opt_x.RL);
              Index = ismember(Block_Label,supp);
              x(Index) = 1;
          else
              Index_0 = randperm(NumBlock);
              Index_1 = Index_0(1:s);
              Index_2 = ismember(Block_Label,Index_1);
              x(Index_2) = 1;
          end
      otherwise
          disp('Wrong parameters are provided. Please check your input related to ''Opt_x'' carefully.')     
  end
   
% Phi
  switch Opt_Phi.Dis
      case  'randn'
          Phi = randn(m,n);
      case  'rand'
          Phi = rand(m,n); 
      case   'hada-mard'
          Phi_original = hadamard(n); 
          Index = randperm(n,m);
          Phi = Phi_original(Index,:)/sqrt(n);
      case   'Gauss'
          Phi = normrnd(0,1/sqrt(m),m,n);
      case   'P_DCT'
          Phi = zeros(m, n);
          r = rand(m, 1);
          for i = 1:n 
              Phi(:, i) = cos(2*(i-1)*pi*r)/sqrt(m);
          end
      case   'OsP_DCT'
          Phi = zeros(m, n);
          r = rand(m, 1);
          for i = 1:n 
              Phi(:, i) = cos(2*(i-1)*pi*r/Opt_Phi.F)/sqrt(m);
          end
      otherwise
          disp('Wrong parameters are provided. Please check your input related to ''Opt_Phi'' carefully.')          
  end    
end


